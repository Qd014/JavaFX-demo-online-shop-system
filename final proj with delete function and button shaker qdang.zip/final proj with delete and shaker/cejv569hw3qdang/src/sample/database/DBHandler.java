package sample.database;

import java.sql.*;

public class DBHandler extends Config {
    Connection dbConnection;

    public Connection getDbConnection() throws SQLException {
        String connectionString = "jdbc:mysql://" + dbHost + ":" + dbPort + "/" + dbName;
        dbConnection = DriverManager.getConnection(connectionString, dbUser, dbPassword);
        return dbConnection;
    }


    public void signUpUser(User user) {
        String query = "INSERT INTO " + Const.USERS_TABLE + "(" +
                Const.USERS_FIRST_NAME + "," +
                Const.USERS_LAST_NAME + "," +
                Const.USERS_USERNAME + "," +
                Const.USERS_PASSWORD + ") VALUES(?,?,?,?)";

        try {
            PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
            preparedStatement.setString(1, user.getFirstName());
            preparedStatement.setString(2, user.getLastName());
            preparedStatement.setString(3, user.getUsername());
            preparedStatement.setString(4, user.getPassword());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


///// DELETE Function
    public void deleteUser(String username) {
        String query = "DELETE FROM " + Const.USERS_TABLE + " WHERE " + Const.USERS_USERNAME + "=? ";
        try {
            PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.execute();
            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


////
////////UPDATE Function
////
////public void deactivateUser(String username) {
////
////    String adminDefault="adminDefault";
////
////    String query = "UPDATE " + Const.USERS_TABLE + "SET "+Const.USERS_USERNAME+ adminDefault +"WHERE " + Const.USERS_USERNAME + "=? ";
////    try {
////        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
////        preparedStatement.setString(1, username);
////        preparedStatement.execute();
////        preparedStatement.close();
////    } catch (SQLException e) {
////        e.printStackTrace();
////    }
////}











///check credentials

    public ResultSet getUser(User user) {
        ResultSet resultSet = null;

        if (!user.getUsername().equals("") && !user.getPassword().equals("")) {
            String query = "SELECT * FROM " + Const.USERS_TABLE + " WHERE " + Const.USERS_USERNAME + "=?" + " AND " + Const.USERS_PASSWORD + "=?";
            try {
                PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);

                preparedStatement.setString(1, user.getUsername());
                preparedStatement.setString(2, user.getPassword());

                resultSet = preparedStatement.executeQuery();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        } else {
            System.out.println("Please enter your credentials");
        }

        return resultSet;
    }

/// get number of users

    public int getNumberOfUsers( ) {
        String query = "SELECT COUNT(*) FROM " + Const.USERS_TABLE ;
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = getDbConnection().prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();



            if (resultSet.next()) {

                System.out.println("current users count: "+resultSet.getInt(1));

                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }



////

    public void insertContact(Contact contact) {
        String query = "INSERT INTO " + Const.CONTACT_TABLE + "(" +
                Const.CONTACT_USERNAME + "," +
                Const.CONTACT_DESCRIPTION + ") VALUES(?,?)";

        try {
            PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
            preparedStatement.setString(1, contact.getUsername());
            preparedStatement.setString(2, contact.getDescription());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }




}