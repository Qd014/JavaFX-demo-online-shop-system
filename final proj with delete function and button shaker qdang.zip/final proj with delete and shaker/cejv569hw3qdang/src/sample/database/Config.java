package sample.database;


public class Config {
    protected String dbHost = "localhost";
    protected String dbPort = "3306";
    //    protected String dbUser = "root";
//    protected String dbPassword = "";
    protected String dbUser = "userqd";
    protected String dbPassword = "passcode#01";
    protected String dbName = "concordia_login";
}