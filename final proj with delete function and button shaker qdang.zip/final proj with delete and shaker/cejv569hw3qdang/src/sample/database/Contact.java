package sample.database;
import java.sql.Timestamp;

public class Contact{
//    private int userId;
    private String username;
//    private Timestamp createdAt;
    private String description;

    public Contact() {
    }

    public Contact(String username, String description) {
//        this.title = title;
        this.username = username;
//        this.createdAt = createdAt;
        this.description = description;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(int userId) {
        this.username = username;
    }

//    public String getTitle() {
//        return title;
//    }
//
//    public void setTitle(String title) {
//        this.title = title;
//    }
//
//    public Timestamp getCreatedAt() {
//        return createdAt;
//    }
//
//    public void setCreatedAt(Timestamp createdAt) {
//        this.createdAt = createdAt;
//    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}