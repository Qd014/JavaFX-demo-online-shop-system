package sample.database;

public class Const {

    // Tables
    public static final String USERS_TABLE = "users";
    public static final String CONTACT_TABLE = "contacts";

    // User Table Columns
    public static final String USERS_USERNAME = "username";
    public static final String USERS_PASSWORD = "password";
    public static final String USERS_LAST_NAME = "lastname";
    public static final String USERS_FIRST_NAME = "firstname";

    // Contact Table Columns

    public static final String CONTACT_USERNAME = "username";
    public static final String CONTACT_DESCRIPTION = "description";
}
