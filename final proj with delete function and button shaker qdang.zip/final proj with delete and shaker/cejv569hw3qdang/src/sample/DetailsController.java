package sample;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.input.KeyEvent;
import sample.database.DBHandler;
import sample.database.User;




public class DetailsController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label welcomeLabel;

    @FXML
    private Button deleteAccountButton;

    @FXML
    private Button deactivateAccountButton;

    @FXML
    private TreeTableColumn<?, ?> tableView;



    @FXML
    void initialize() {
// assert welcomeLabel != null : "fx:id=\"welcomeLabel\" was not injected: check your FXML file 'details.fxml'.";
// every time add a label in fxml, copy the scene builder view-controller into the ide's controller

        deleteAccountButton.setOnAction(actionEvent -> {
            System.out.println("---User Clicked the delete account button---");

//                deleteAccount(user.getUsername());
                deleteAccount();
        });



//////
        deactivateAccountButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                System.out.println("---User Clicked the deactivate account button---");

//                deactivateAccount();
            }
        });
        /////

    }

    private void deleteAccount() {

        DBHandler dbHandler = new DBHandler();

        dbHandler.deleteUser(LoginController.username);

        System.out.println("---User deleted his account---");
        }


//    private void deactivateAccount() {
//
//        DBHandler dbHandler = new DBHandler();
//
//        dbHandler.deactivateUser(LoginController.username);
//
//        System.out.println("---User deactivated his account, password reset to adminDefault---");
//    }


    public void setLabels(String name, String profession, int age) {
        this.welcomeLabel.setText("Welcome, " + name+ "!");

    }




}
