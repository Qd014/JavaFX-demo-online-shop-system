package sample;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import sample.database.Const;
import sample.database.DBHandler;
import sample.database.Shaker;
import sample.database.User;

//import static sample.database.DBHandler.getNumberOfUsers;

public class SignupController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label signupLabel;

    @FXML
    private Label signupLabel1;

    @FXML
    private Button signupSubmit;

//    @FXML
//    private Button backtologinbutton;


    @FXML
    private TextField signupfirstnameTextField;

    @FXML
    private TextField signuplastnameTextField;

    @FXML
    private TextField signupusernameTextField;

    @FXML
    private TextField signuppasswordTextField;

//    public SignupController(Button backtologinbutton) {
//        this.backtologinbutton = backtologinbutton;
//    }

    @FXML
    void initialize() {
        assert signupSubmit != null : "fx:id=\"signupSubmit\" was not injected: check your FXML file 'signup.fxml'.";

        DBHandler dbHandler = new DBHandler();
//        dbHandler.getNumberOfUsers( );
        this.signupLabel1.setText("Current users we have: "+dbHandler.getNumberOfUsers( ));


        signupSubmit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                System.out.println("---User Clicked the Sign Up Submit button---");
                signupUser();

                DBHandler dbHandler = new DBHandler();
                signupLabel1.setText("Current users we have: "+dbHandler.getNumberOfUsers( ));

            }
        });





////



//        backtologinbutton.setOnAction(new EventHandler<ActionEvent>() {
//            @Override
//            public void handle(ActionEvent actionEvent) {
//                System.out.println("---User Clicked the back to login button---");
//
//                backToLogin();
//            }
//        });


    }


//    private void backToLogin() {
//        backtologinbutton.getScene().getWindow().hide();//hide old popup page if new fxml loaded
//
//        //Pop out new page by FXMLLoader!
//        FXMLLoader fxmlLoader = new FXMLLoader();
//
////            fxmlLoader.setLocation(getClass().getResource("/com/concordia/loginpage/details.fxml"));
//        fxmlLoader.setLocation(getClass().getResource("/sample\\login.fxml"));
////remember to add "/" in path beginning, after left click details.fxml - copy - copy the path
//
////check if wrong path
//        try {
//            fxmlLoader.load();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        Parent root = fxmlLoader.getRoot();
//        Stage detailsStage = new Stage();
//
//        Scene scene = new Scene(root);
//        detailsStage.setScene(scene);
//
////            DetailsController detailsController = fxmlLoader.getController();
////            detailsController.setLabels(username, "JavaFX Developer", 25);
//
//        detailsStage.show();
////            detailsStage.setResizable(false);
//    }





    private void signupUser() {
//        signupSubmit.getScene().getWindow().hide();//hide old popup page if new fxml loaded

        String signupfirstname = signupfirstnameTextField.getText().trim();
        String signuplastname = signuplastnameTextField.getText().trim();
        String signupusername = signupusernameTextField.getText().trim();
        String signuppassword = signuppasswordTextField.getText().trim();

        System.out.println("\n signupfirstname =" + signupfirstname + "\n signuplastname =" + signuplastname + "\n signupusername =" + signupusername + "\n signuppassword =" + signuppassword);



///////////////////
        DBHandler dbHandler = new DBHandler();

        String firstName = signupfirstnameTextField.getText().trim();
        String lastName = signuplastnameTextField.getText().trim();
        String username = signupusernameTextField.getText().trim();
        String password = signuppasswordTextField.getText().trim();


            if (firstName.length() != 0 && lastName.length() != 0 && username.length() != 0 && password.length() != 0 )
            {

                User user = new User(firstName, lastName, username, password);
                dbHandler.signUpUser(user);
                System.out.println("---User successfully signed up---");
                this.signupLabel.setText("Dear " + signupusername + "," + "\nYou are now signed up, thank you!");

            } else {
                new Shaker(signupfirstnameTextField).shake();
                new Shaker(signuplastnameTextField).shake();
                new Shaker(signupusernameTextField).shake();
                new Shaker(signuppasswordTextField).shake();

            }


    }
}