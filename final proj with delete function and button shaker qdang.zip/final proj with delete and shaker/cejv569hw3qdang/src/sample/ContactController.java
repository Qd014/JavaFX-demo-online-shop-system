package sample;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import sample.database.Contact;
import sample.database.DBHandler;
import sample.database.User;

public class ContactController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;


    @FXML
    private Label commentLabel;

    @FXML
    private TextField nameleftField;

    @FXML
    private TextField messageleftField;

    @FXML
    private Button submitButton;

    @FXML
    void initialize() {
        assert commentLabel != null : "fx:id=\"commentLabel\" was not injected: check your FXML file 'contact.fxml'.";


        submitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                System.out.println("---User Clicked the submit button in contact us---");

                submitComment();
            }
        });



    }

    public void submitComment() {

        String nameleft = nameleftField.getText().trim();
        String messageleft = messageleftField.getText().trim();

        this.commentLabel.setText("Dear customer " +nameleft+","+"\n\n We have received your request, \n someone will contact you soon!");
        //scene builder's label block has a .setText() method
//        this.nameLabel.setText("Name: " + name);
//        this.professionLabel.setText("Profession: " + profession);
//        this.ageLabel.setText("Age: " + age);
        System.out.println("\n name left at contact page = " +nameleft );
        System.out.println("\n message left at contact page = " + messageleft);

        ///////
        DBHandler dbHandler = new DBHandler();


        Contact contact = new Contact(nameleft,messageleft);

        dbHandler.insertContact(contact);








    }


}

