package sample;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import sample.database.DBHandler;
import sample.database.Shaker;
import sample.database.User;

public class LoginController {


    public static String username;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
////
    @FXML
//    public static TextField usernameTextField;
    private TextField usernameTextField;
    @FXML
    private PasswordField passwordField;

////
    @FXML
    private Button loginButton;

    @FXML
    private Button contactusButton;

    @FXML
    private Button signupButton;


    @FXML
    void initialize() {
//        assert usernameTextField != null : "fx:id=\"usernameTextField\" was not injected: check your FXML file 'login.fxml'.";
//        assert passwordField != null : "fx:id=\"passwordField\" was not injected: check your FXML file 'login.fxml'.";

//        usernameTextField.setStyle("-fx-background-color: #4f5b62; -fx-text-fill: #4f5b62");
//        passwordField.setStyle("-fx-background-color: #4f5b62; -fx-text-fill: #ffffff");




/////////////////////        Disable Button when TextField is empty? 2021-11-10 Q.Dang
        loginButton.disableProperty().bind(
                Bindings.isEmpty(usernameTextField.textProperty())
                        .or(Bindings.isEmpty(passwordField.textProperty()))
//                        .and(Bindings.isEmpty(textField3.textProperty()))
        );
/////////////////////



        loginButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                System.out.println("---User Clicked the login button---");

                loginUser();

//                getNumberOfTasks( );
            }
        });

        /////
        DBHandler dbHandler = new DBHandler();
        loginButton.setOnAction(actionEvent -> {
            username = usernameTextField.getText().trim();
            String password = passwordField.getText().trim();

            User user = new User();
            user.setUsername(username);
            user.setPassword(password);

            ResultSet resultSet = dbHandler.getUser(user);

            try {
                if (resultSet != null && resultSet.next()) {
                    int userId = resultSet.getInt("id");
//                    showAddItemScreen();
                        System.out.println("---User Clicked the login button---");
                        loginUser();

                } else {
                    new Shaker(passwordField).shake();
                    new Shaker(usernameTextField).shake();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
        //////

        contactusButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                System.out.println("---User Clicked the contact us button---");

                contactUs();
            }
        });

        signupButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                System.out.println("---User Clicked the signup button---");

                signupUser();
            }
        });


    }


    private void loginUser() {
        loginButton.getScene().getWindow().hide();//hide old popup page if new fxml loaded

        username = usernameTextField.getText().trim();
        String password = passwordField.getText().trim();

        if (!username.equals("") && !password.equals("")) {
            //Pop out new page by FXMLLoader!
            FXMLLoader fxmlLoader = new FXMLLoader();

//            fxmlLoader.setLocation(getClass().getResource("/com/concordia/loginpage/details.fxml"));
            fxmlLoader.setLocation(getClass().getResource("/sample\\details.fxml"));
//remember to add "/" in path beginning, after left click details.fxml - copy - copy the path

//check if wrong path
            try {
                fxmlLoader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = fxmlLoader.getRoot();
            Stage detailsStage = new Stage();

            Scene scene = new Scene(root);
            detailsStage.setScene(scene);

            DetailsController detailsController = fxmlLoader.getController();
            detailsController.setLabels(username, "JavaFX Developer", 25);

            detailsStage.show();
//            detailsStage.setResizable(false);
        }
    }

    private void contactUs() {
//        loginButton.getScene().getWindow().hide();//hide old popup page if new fxml loaded

            //Pop out new page by FXMLLoader!
            FXMLLoader fxmlLoader = new FXMLLoader();

//            fxmlLoader.setLocation(getClass().getResource("/com/concordia/loginpage/details.fxml"));
            fxmlLoader.setLocation(getClass().getResource("/sample\\contact.fxml"));
//remember to add "/" in path beginning, after left click details.fxml - copy - copy the path

//check if wrong path
            try {
                fxmlLoader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = fxmlLoader.getRoot();
            Stage detailsStage = new Stage();

            Scene scene = new Scene(root);
            detailsStage.setScene(scene);

            detailsStage.show();

        }



    private void signupUser() {
//        loginButton.getScene().getWindow().hide();//hide old popup page if new fxml loaded

        //Pop out new page by FXMLLoader!
        FXMLLoader fxmlLoader = new FXMLLoader();

//            fxmlLoader.setLocation(getClass().getResource("/com/concordia/loginpage/details.fxml"));
        fxmlLoader.setLocation(getClass().getResource("/sample\\signup.fxml"));
//remember to add "/" in path beginning, after left click details.fxml - copy - copy the path

//check if wrong path
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root = fxmlLoader.getRoot();
        Stage detailsStage = new Stage();

        Scene scene = new Scene(root);
        detailsStage.setScene(scene);

//            DetailsController detailsController = fxmlLoader.getController();
//            detailsController.setLabels(username, "JavaFX Developer", 25);

        detailsStage.show();
//            detailsStage.setResizable(false);
    }
}




